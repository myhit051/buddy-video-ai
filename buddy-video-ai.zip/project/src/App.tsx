import React, { useState } from 'react';
import { 
  Play, 
  FileText, 
  Video, 
  Folder, 
  Settings, 
  Sparkles, 
  Clock, 
  Target,
  Palette,
  Bot,
  User
} from 'lucide-react';

function App() {
  const [activeTab, setActiveTab] = useState('generate');
  const [topic, setTopic] = useState('');
  const [platform, setPlatform] = useState('youtube-shorts');
  const [duration, setDuration] = useState('30');
  const [style, setStyle] = useState('modern');

  const sidebarItems = [
    { id: 'blog', icon: FileText, label: 'Blog', color: 'text-blue-400' },
    { id: 'script', icon: FileText, label: 'Script', color: 'text-green-400' },
    { id: 'generate', icon: Video, label: 'Video', color: 'text-purple-400' },
    { id: 'materials', icon: Folder, label: 'Materials', color: 'text-orange-400' },
    { id: 'settings', icon: Settings, label: 'Settings', color: 'text-gray-400' },
  ];

  const platforms = [
    { id: 'youtube-shorts', name: 'YouTube Shorts', desc: 'Vertical videos up to 60s' },
    { id: 'tiktok', name: 'TikTok', desc: 'Short-form vertical content' },
    { id: 'facebook-reels', name: 'Facebook Reels', desc: 'Social video content' },
    { id: 'instagram-reels', name: 'Instagram Reels', desc: 'Engaging short videos' },
  ];

  const styles = [
    { id: 'modern', name: 'Modern', desc: 'Clean and contemporary' },
    { id: 'cinematic', name: 'Cinematic', desc: 'Movie-like quality' },
    { id: 'casual', name: 'Casual', desc: 'Relaxed and friendly' },
    { id: 'educational', name: 'Educational', desc: 'Informative content' },
  ];

  const features = [
    { icon: Bot, title: 'AI-Powered', desc: 'Advanced AI generates content automatically' },
    { icon: FileText, title: 'Script Writing', desc: 'Create engaging scripts with AI assistance' },
    { icon: Play, title: 'Voice Generation', desc: 'Generate natural-sounding voiceovers' },
    { icon: Video, title: 'Video Creation', desc: 'Produce high-quality videos instantly' },
    { icon: Palette, title: 'Style Customization', desc: 'Choose from various visual styles' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-sm border-b border-gray-700/50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Buddy Video AI</h1>
                <p className="text-sm text-gray-400">AI Video Generator</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="bg-purple-500/20 text-purple-300 px-3 py-1 rounded-full text-sm font-medium">
                MEMBER
              </div>
              <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-gray-300" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-black/30 backdrop-blur-sm border-r border-gray-700/50 min-h-screen">
          <nav className="p-4 space-y-2">
            {sidebarItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                    activeTab === item.id
                      ? 'bg-purple-500/20 text-purple-300 shadow-lg'
                      : 'text-gray-400 hover:text-white hover:bg-gray-700/30'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${activeTab === item.id ? item.color : ''}`} />
                  <span className="font-medium">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {activeTab === 'generate' && (
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-white mb-4">
                  Create AI-Generated Videos
                </h2>
                <p className="text-gray-400 text-lg">
                  Generate engaging content for YouTube Shorts, TikTok, Facebook Reels, and Instagram Reels automatically
                </p>
              </div>

              <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50">
                <div className="space-y-6">
                  {/* Topic Input */}
                  <div>
                    <label className="block text-white font-medium mb-3 flex items-center space-x-2">
                      <Target className="w-5 h-5 text-blue-400" />
                      <span>Topic (หัวข้อ)</span>
                    </label>
                    <input
                      type="text"
                      value={topic}
                      onChange={(e) => setTopic(e.target.value)}
                      placeholder="Enter your video topic..."
                      className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Platform Selection */}
                  <div>
                    <label className="block text-white font-medium mb-3 flex items-center space-x-2">
                      <Video className="w-5 h-5 text-green-400" />
                      <span>Platform (สำหรับโปรเจ็กต์)</span>
                    </label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {platforms.map((p) => (
                        <button
                          key={p.id}
                          onClick={() => setPlatform(p.id)}
                          className={`p-4 rounded-lg border transition-all duration-200 text-left ${
                            platform === p.id
                              ? 'bg-purple-500/20 border-purple-400 text-purple-300'
                              : 'bg-gray-700/30 border-gray-600 text-gray-300 hover:bg-gray-700/50'
                          }`}
                        >
                          <div className="font-medium">{p.name}</div>
                          <div className="text-sm opacity-75">{p.desc}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Duration */}
                  <div>
                    <label className="block text-white font-medium mb-3 flex items-center space-x-2">
                      <Clock className="w-5 h-5 text-orange-400" />
                      <span>Duration (ระยะเวลา)</span>
                    </label>
                    <select
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
                    >
                      <option value="15">15 seconds</option>
                      <option value="30">30 seconds</option>
                      <option value="60">60 seconds</option>
                      <option value="90">90 seconds</option>
                    </select>
                  </div>

                  {/* Style Selection */}
                  <div>
                    <label className="block text-white font-medium mb-3 flex items-center space-x-2">
                      <Palette className="w-5 h-5 text-pink-400" />
                      <span>Style (รูปแบบ)</span>
                    </label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {styles.map((s) => (
                        <button
                          key={s.id}
                          onClick={() => setStyle(s.id)}
                          className={`p-4 rounded-lg border transition-all duration-200 text-left ${
                            style === s.id
                              ? 'bg-purple-500/20 border-purple-400 text-purple-300'
                              : 'bg-gray-700/30 border-gray-600 text-gray-300 hover:bg-gray-700/50'
                          }`}
                        >
                          <div className="font-medium">{s.name}</div>
                          <div className="text-sm opacity-75">{s.desc}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Generate Button */}
                  <button className="w-full bg-gradient-to-r from-purple-500 to-blue-500 text-white font-bold py-4 px-8 rounded-lg hover:from-purple-600 hover:to-blue-600 transition-all duration-200 transform hover:scale-[1.02] shadow-lg hover:shadow-xl flex items-center justify-center space-x-2">
                    <Sparkles className="w-5 h-5" />
                    <span>GENERATE</span>
                  </button>
                </div>
              </div>

              {/* Features Section */}
              <div className="mt-12">
                <h3 className="text-2xl font-bold text-white mb-6 text-center">
                  What You Can Do
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {features.map((feature, index) => {
                    const Icon = feature.icon;
                    return (
                      <div
                        key={index}
                        className="bg-gray-800/30 backdrop-blur-sm rounded-xl p-6 border border-gray-700/50 hover:bg-gray-800/50 transition-all duration-200"
                      >
                        <div className="mb-4">
                          <Icon className="w-8 h-8 text-purple-400" />
                        </div>
                        <h4 className="text-lg font-semibold text-white mb-2">
                          {feature.title}
                        </h4>
                        <p className="text-gray-400">
                          {feature.desc}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {activeTab !== 'generate' && (
            <div className="max-w-4xl mx-auto text-center">
              <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-12 border border-gray-700/50">
                <div className="w-16 h-16 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Sparkles className="w-8 h-8 text-purple-400" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-4">
                  {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Section
                </h2>
                <p className="text-gray-400">
                  This section is under development. Stay tuned for more features!
                </p>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

export default App;